
package com.test.sdk.common;

public interface SdkHttpListener {

    public void onResponse(String response);

    public void onCancelled();

}
