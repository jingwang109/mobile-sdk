
package com.test.sdk.activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

import com.qihoo.gamecenter.sdk.common.IDispatcherCallback;
import com.qihoo.gamecenter.sdk.protocols.pay.ProtocolKeys;
import com.qihoopay.insdk.matrix.Matrix;
import com.test.sdk.Constants;
import com.test.sdk.R;
import com.test.sdk.appserver.QihooUserInfo;
import com.test.sdk.appserver.QihooUserInfoListener;
import com.test.sdk.appserver.QihooUserInfoTask;
import com.test.sdk.appserver.TokenInfo;
import com.test.sdk.appserver.TokenInfoListener;
import com.test.sdk.appserver.TokenInfoTask;
import com.test.sdk.common.SdkUserBaseActivity;
import com.test.sdk.utils.ProgressUtil;

public class SdkWelcomeActivity extends SdkUserBaseActivity implements OnClickListener,
        TokenInfoListener, QihooUserInfoListener {

    private static final String TAG = "SdkGuestActivity";

    private TextView mLoginResultView;

    private ProgressDialog mProgress;

    private TokenInfo mTokenInfo;

    private QihooUserInfo mQihooUserInfo;

    private boolean mIsLandscape;

    private TokenInfoTask mTokenTask;
    private QihooUserInfoTask mUserInfoTask;

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_login_bg_transparent:
                clearLoginResult();
                // 调用360SDK登录（是否横屏显示、透明背景）
                doSdkLogin(mIsLandscape, true);
                break;
            case R.id.btn_login:
                clearLoginResult();
                // 调用360SDK登录（是否横屏显示、不透明背景）
                doSdkLogin(mIsLandscape, false);
                break;
            case R.id.btn_flow_test: {
                // 打开流程测试登录界面
                Intent intent = new Intent(this, FlowTestLoginActivity.class);
                intent.putExtra(ProtocolKeys.IS_SCREEN_ORIENTATION_LANDSCAPE, mIsLandscape);
                startActivity(intent);
            }
                break;
            case R.id.btn_quit:
                // 调用360SDK退出（是否横屏显示）
                doSdkQuit(mIsLandscape);
                break;
            case R.id.btn_self_check:
                doSdkSelfCheck();
                break;
            case R.id.btn_get_out_sdk_info:
                doSdkProInfoQuery();
                break;
            case R.id.btn_bbs:
                doSdkBBS(mIsLandscape);
                break;
            default:
                break;
        }

    }

    /**
     * 360SDK登录，通过此方法返回授权码（授权码生存期只有60秒，必需立即请求应用服务器，以得到AccessToken）
     */
    @Override
    public void onGotAuthorizationCode(String authorizationCode) {

        if (TextUtils.isEmpty(authorizationCode)) {
            Toast.makeText(this, R.string.get_code_fail, Toast.LENGTH_LONG).show();
        } else {
            clearLoginResult();
            mTokenTask = TokenInfoTask.newInstance();
            // 提示用户进度
            mProgress = ProgressUtil.show(this, R.string.get_token_title,
                    R.string.get_token_message, new OnCancelListener() {

                        @Override
                        public void onCancel(DialogInterface dialog) {
                            if (mTokenTask != null) {
                                mTokenTask.doCancel();
                            }
                        }
                    });

            // 请求应用服务器，用AuthorizationCode换取AccessToken
            mTokenTask.doRequest(this, authorizationCode, Matrix.getAppKey(this), this);
        }
    }

    /**
     * 应用服务器通过此方法返回AccessToken
     */
    @Override
    public void onGotTokenInfo(TokenInfo tokenInfo) {

        if (tokenInfo == null || TextUtils.isEmpty(tokenInfo.getAccessToken())) {
            ProgressUtil.dismiss(mProgress);
            Toast.makeText(this, R.string.get_token_fail, Toast.LENGTH_LONG).show();
        } else {
            // 保存TokenInfo
            mTokenInfo = tokenInfo;
            mUserInfoTask = QihooUserInfoTask.newInstance();
            // 界面显示AccessToken
            mLoginResultView.setText(getLoginResultText());

            // 提示用户进度
            ProgressUtil.setText(mProgress, getString(R.string.get_user_title),
                    getString(R.string.get_user_message), new OnCancelListener() {

                        @Override
                        public void onCancel(DialogInterface dialog) {
                            if (mUserInfoTask != null) {
                                mUserInfoTask.doCancel();
                            }
                        }
                    });

            // 请求应用服务器，用AccessToken换取UserInfo
            mUserInfoTask.doRequest(this, tokenInfo.getAccessToken(), Matrix.getAppKey(this), this);
        }

    }

    /**
     * 应用服务器通过此方法返回UserInfo
     */
    @Override
    public void onGotUserInfo(QihooUserInfo userInfo) {

        ProgressUtil.dismiss(mProgress);

        if (userInfo != null && userInfo.isValid()) {
            // 保存QihooUserInfo
            mQihooUserInfo = userInfo;

            // 界面显示QihooUser的Id和Name
            mLoginResultView.setText(getLoginResultText());

            startSdkUserActivity();
        } else {
            Toast.makeText(this, R.string.get_user_fail, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onGotError(int errCode) {
        clearLoginResult();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                doSdkQuit(mIsLandscape);
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mIsLandscape = getIntent().getBooleanExtra(Constants.IS_LANDSCAPE, true);
        setRequestedOrientation(mIsLandscape ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setContentView(R.layout.sdk_welcome_activity);

        if (savedInstanceState == null) {
            // 初始化
            Matrix.init(this, false, new IDispatcherCallback() {
                @Override
                public void onFinished(String data) {
                    Log.d(TAG, "matrix startup callback,result is " + data);
                }
            });
        }
        resetViews();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Matrix.destroy(this);
        if (mTokenTask != null) {
            mTokenTask.doCancel();
        }

        if (mUserInfoTask != null) {
            mUserInfoTask.doCancel();
        }
    }

    private void resetViews() {

        TextView sdkVerView = (TextView) findViewById(R.id.sdk_ver);
        sdkVerView.setText(getString(R.string.sdk_ver).concat(Matrix.getVersionName(this)));

        TextView channelView = (TextView) findViewById(R.id.channel);
        channelView.setText(getString(R.string.channel).concat(Matrix.getChannel(this)));

        mLoginResultView = (TextView) findViewById(R.id.login_result);
        mLoginResultView.setText(getLoginResultText());

        View btnLoginBgTransparent = findViewById(R.id.btn_login_bg_transparent);
        btnLoginBgTransparent.setOnClickListener(this);

        View btnLogin = findViewById(R.id.btn_login);
        btnLogin.setOnClickListener(this);

        View btnQuit = findViewById(R.id.btn_quit);
        btnQuit.setOnClickListener(this);

        View btnFlowTest = findViewById(R.id.btn_flow_test);
        btnFlowTest.setOnClickListener(this);

        View btnSelfCheck = findViewById(R.id.btn_self_check);
        btnSelfCheck.setOnClickListener(this);

        View btnGetOutSDKInfo = findViewById(R.id.btn_get_out_sdk_info);
        btnGetOutSDKInfo.setOnClickListener(this);

        View btnBBS = findViewById(R.id.btn_bbs);
        btnBBS.setOnClickListener(this);

    }

    private String getLoginResultText() {
        String result;
        if (mTokenInfo == null) {
            result = getString(R.string.nologin);
        } else {
            result = getString(R.string.formal_account);
            if (mTokenInfo != null && !TextUtils.isEmpty(mTokenInfo.getAccessToken())) {
                result += ("TokenInfo=" + mTokenInfo.toJsonString() + "\n\n");
            }

            if (mQihooUserInfo != null && mQihooUserInfo.isValid()) {
                result += ("UserInfo=" + mQihooUserInfo.toJsonString());
            }
        }

        return result;
    }

    private void clearLoginResult() {
        mTokenInfo = null;
        mQihooUserInfo = null;
        mLoginResultView.setText(getLoginResultText());
    }

    private void startSdkUserActivity() {
        Intent intent = new Intent(this, SdkUserActivity.class);
        intent.putExtra(Constants.TOKEN_INFO, mTokenInfo.toJsonString());
        intent.putExtra(Constants.QIHOO_USER_INFO, mQihooUserInfo.toJsonString());
        intent.putExtra(Constants.IS_LANDSCAPE, mIsLandscape);
        startActivity(intent);
        finish();
    }

}
