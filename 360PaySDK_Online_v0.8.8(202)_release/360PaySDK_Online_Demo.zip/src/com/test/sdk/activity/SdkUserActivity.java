
package com.test.sdk.activity;

import com.qihoopay.insdk.matrix.Matrix;
import com.test.sdk.Constants;
import com.test.sdk.R;
import com.test.sdk.appserver.QihooUserInfo;
import com.test.sdk.appserver.QihooUserInfoListener;
import com.test.sdk.appserver.QihooUserInfoTask;
import com.test.sdk.appserver.TokenInfo;
import com.test.sdk.appserver.TokenInfoListener;
import com.test.sdk.appserver.TokenInfoTask;
import com.test.sdk.common.QihooPayInfo;
import com.test.sdk.common.SdkUserBaseActivity;
import com.test.sdk.utils.ProgressUtil;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

public class SdkUserActivity extends SdkUserBaseActivity implements OnClickListener,
        TokenInfoListener, QihooUserInfoListener {

    private static final String TAG = "SdkUserActivity";

    private TextView mLoginResultView;

    private ProgressDialog mProgress;

    private TokenInfo mTokenInfo;

    private QihooUserInfo mQihooUserInfo;

    private boolean mIsLandscape;
    private TokenInfoTask mTokenTask;
    private QihooUserInfoTask mUserInfoTask;

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_fixed_pay_bg_transparent: {
                // 调用360SDK定额支付（是否横屏显示、透明背景）
                doSdkPay(mIsLandscape, true, true);
            }
                break;
            case R.id.btn_fixed_pay_bg_visible: {
                // 调用360SDK定额支付（是否横屏显示、不透明背景）
                doSdkPay(mIsLandscape, true, false);
            }
                break;
            case R.id.btn_not_fixed_pay_bg_transparent: {
                // 调用360SDK不定额支付（是否横屏显示、透明背景）
                doSdkPay(mIsLandscape, false, true);
            }
                break;
            case R.id.btn_not_fixed_pay_bg_visible: {
                // 调用360SDK不定额支付（是否横屏显示、不透明背景）
                doSdkPay(mIsLandscape, false, false);
            }
                break;
            case R.id.btn_quit:
                // 调用360SDK退出（是否横屏显示）
                doSdkQuit(mIsLandscape);
                break;

            case R.id.btn_real_name_register_bg_transparent: {
                if (mQihooUserInfo == null || mTokenInfo == null) {
                    Toast.makeText(this, "请先登录", Toast.LENGTH_LONG).show();
                    return;
                }
                // 实名注册（是否横屏显示）
                doSdkRealNameRegister(mIsLandscape, true, mQihooUserInfo.getId());
            }
                break;
            case R.id.btn_real_name_register_bg_visible: {
                if (mQihooUserInfo == null || mTokenInfo == null) {
                    Toast.makeText(this, "请先登录", Toast.LENGTH_LONG).show();
                    return;
                }
                // 实名注册（是否横屏显示）
                doSdkRealNameRegister(mIsLandscape, false, mQihooUserInfo.getId());
            }
                break;
            case R.id.btn_anti_addiction_query: {
                if (mQihooUserInfo == null || mTokenInfo == null) {
                    Toast.makeText(this, "请先登录", Toast.LENGTH_LONG).show();
                    return;
                }
                // 防沉迷查询
                doSdkAntiAddictionQuery(mQihooUserInfo.getId(), mTokenInfo.getAccessToken());
            }
                break;
            case R.id.btn_switch_account_bg_transparent:
                // 调用360SDK切换账号（是否横屏显示、透明背景）
                doSdkSwitchAccount(mIsLandscape, true);
                break;
            case R.id.btn_switch_account:
                // 调用360SDK切换账号（是否横屏显示、不透明背景）
                doSdkSwitchAccount(mIsLandscape, false);
                break;
            case R.id.btn_self_check:
                doSdkSelfCheck();
                break;
            case R.id.btn_get_out_sdk_info:
                doSdkProInfoQuery();
                break;
            case R.id.btn_bbs:
                doSdkBBS(mIsLandscape);
                break;
            case R.id.btn_customer:
                doSdkCustomerService(mIsLandscape);
                break;
            case R.id.btn_bind: {
                if (mQihooUserInfo == null || mTokenInfo == null) {
                    Toast.makeText(this, "请先登录", Toast.LENGTH_LONG).show();
                    return;
                }
                doSdkBindPhoneNum(mIsLandscape);
            }
                break;
            default:
                break;
        }
    }

    /**
     * 360SDK登录，通过此方法返回授权码（授权码生存期只有60秒，必需立即请求应用服务器，以得到AccessToken）
     */
    @Override
    public void onGotAuthorizationCode(String authorizationCode) {
        if (TextUtils.isEmpty(authorizationCode)) {
            Toast.makeText(this, R.string.get_code_fail, Toast.LENGTH_LONG).show();
        } else {
            clearLoginResult();
            mTokenTask = TokenInfoTask.newInstance();
            // 提示用户进度
            mProgress = ProgressUtil.show(this, R.string.get_token_title,
                    R.string.get_token_message, new OnCancelListener() {

                        @Override
                        public void onCancel(DialogInterface dialog) {
                            if (mTokenTask != null) {
                                mTokenTask.doCancel();
                            }
                        }
                    });

            // 请求应用服务器，用AuthorizationCode换取AccessToken
            mTokenTask.doRequest(this, authorizationCode, Matrix.getAppKey(this), this);
        }
    }

    /**
     * 应用服务器通过此方法返回AccessToken
     */
    @Override
    public void onGotTokenInfo(TokenInfo tokenInfo) {

        if (tokenInfo == null || TextUtils.isEmpty(tokenInfo.getAccessToken())) {
            ProgressUtil.dismiss(mProgress);
            Toast.makeText(this, R.string.get_token_fail, Toast.LENGTH_LONG).show();
        } else {
            // 保存TokenInfo
            mTokenInfo = tokenInfo;
            mUserInfoTask = QihooUserInfoTask.newInstance();
            // 界面显示AccessToken
            mLoginResultView.setText(getLoginResultText());

            // 提示用户进度
            ProgressUtil.setText(mProgress, getString(R.string.get_user_title),
                    getString(R.string.get_user_message), new OnCancelListener() {

                        @Override
                        public void onCancel(DialogInterface dialog) {
                            if (mUserInfoTask != null) {
                                mUserInfoTask.doCancel();
                            }
                        }
                    });

            // 请求应用服务器，用AccessToken换取UserInfo
            mUserInfoTask.doRequest(this, tokenInfo.getAccessToken(), Matrix.getAppKey(this),
                    this);
        }

    }

    /**
     * 应用服务器通过此方法返回UserInfo
     */
    @Override
    public void onGotUserInfo(QihooUserInfo userInfo) {

        ProgressUtil.dismiss(mProgress);

        if (userInfo != null && userInfo.isValid()) {
            // 保存QihooUserInfo
            mQihooUserInfo = userInfo;

            // 界面显示QihooUser的Id和Name
            mLoginResultView.setText(getLoginResultText());

        } else {
            Toast.makeText(this, R.string.get_user_fail, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onGotError(int errCode) {
        // TODO Auto-generated method stub

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                startSdkWelcomeActivity(mIsLandscape);
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        mIsLandscape = intent.getBooleanExtra(Constants.IS_LANDSCAPE, true);
        setRequestedOrientation(mIsLandscape ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        mTokenInfo = TokenInfo.parseJson(intent.getStringExtra(Constants.TOKEN_INFO));
        mQihooUserInfo = QihooUserInfo.parseJson(intent.getStringExtra(Constants.QIHOO_USER_INFO));

        setContentView(R.layout.sdk_user_activity);

        resetViews();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Matrix.destroy(this);
        if (mTokenTask != null) {
            mTokenTask.doCancel();
        }

        if (mUserInfoTask != null) {
            mUserInfoTask.doCancel();
        }
    }

    private void resetViews() {

        TextView sdkVerView = (TextView) findViewById(R.id.sdk_ver);
        sdkVerView.setText(getString(R.string.sdk_ver).concat(Matrix.getVersionName(this)));

        TextView channelView = (TextView) findViewById(R.id.channel);
        channelView.setText(getString(R.string.channel).concat(Matrix.getChannel(this)));

        mLoginResultView = (TextView) findViewById(R.id.login_result);
        mLoginResultView.setText(getLoginResultText());

        View btnFixedPayBgTransparent = findViewById(R.id.btn_fixed_pay_bg_transparent);
        btnFixedPayBgTransparent.setOnClickListener(this);

        View btnFixedPayBgVisible = findViewById(R.id.btn_fixed_pay_bg_visible);
        btnFixedPayBgVisible.setOnClickListener(this);

        View btnNotFixedPayBgTransparent = findViewById(R.id.btn_not_fixed_pay_bg_transparent);
        btnNotFixedPayBgTransparent.setOnClickListener(this);

        View btnNotFixedPayBgVisible = findViewById(R.id.btn_not_fixed_pay_bg_visible);
        btnNotFixedPayBgVisible.setOnClickListener(this);

        View btnQuit = findViewById(R.id.btn_quit);
        btnQuit.setOnClickListener(this);

        View realNameRegisterBgTransparent = findViewById(R.id.btn_real_name_register_bg_transparent);
        realNameRegisterBgTransparent.setOnClickListener(this);

        View realNameRegister = findViewById(R.id.btn_real_name_register_bg_visible);
        realNameRegister.setOnClickListener(this);

        View antiAddictionQuery = findViewById(R.id.btn_anti_addiction_query);
        antiAddictionQuery.setOnClickListener(this);

        View btnSwitchAccountBgTransparent = findViewById(R.id.btn_switch_account_bg_transparent);
        btnSwitchAccountBgTransparent.setOnClickListener(this);

        View btnSwitchAccount = findViewById(R.id.btn_switch_account);
        btnSwitchAccount.setOnClickListener(this);

        View btnSelfCheck = findViewById(R.id.btn_self_check);
        btnSelfCheck.setOnClickListener(this);

        View btnGetOutSDKInfo = findViewById(R.id.btn_get_out_sdk_info);
        btnGetOutSDKInfo.setOnClickListener(this);

        View btnBind = findViewById(R.id.btn_bind);
        btnBind.setOnClickListener(this);

        View btnBBS = findViewById(R.id.btn_bbs);
        btnBBS.setOnClickListener(this);

        View btnCS = findViewById(R.id.btn_customer);
        btnCS.setOnClickListener(this);
    }

    @Override
    protected QihooPayInfo getQihooPayInfo(boolean isFixed) {
        QihooPayInfo payInfo = null;
        if (isFixed) {
            payInfo = getQihooPay(Constants.DEMO_FIXED_PAY_MONEY_AMOUNT);
        }
        else {
            payInfo = getQihooPay(Constants.DEMO_NOT_FIXED_PAY_MONEY_AMOUNT);
        }

        return payInfo;
    }

    /***
     * @param moneyAmount 金额数，使用者可以自由设定数额。金额数为100的整数倍，360SDK运行定额支付流程；
     *            金额数为0，360SDK运行不定额支付流程。
     * @return QihooPay
     */
    private QihooPayInfo getQihooPay(String moneyAmount) {
        // 登录得到AccessToken和UserId，用于支付。TODO null的情况还让请求支付吗？
        String accessToken = (mTokenInfo != null) ? mTokenInfo.getAccessToken() : null;
        String qihooUserId = (mQihooUserInfo != null) ? mQihooUserInfo.getId() : null;

        // 创建QihooPay
        QihooPayInfo qihooPay = new QihooPayInfo();
        qihooPay.setAccessToken(accessToken);
        qihooPay.setQihooUserId(qihooUserId);

        qihooPay.setMoneyAmount(moneyAmount);
        qihooPay.setExchangeRate(Constants.DEMO_PAY_EXCHANGE_RATE);

        qihooPay.setProductName(getString(R.string.demo_pay_product_name));
        qihooPay.setProductId(Constants.DEMO_PAY_PRODUCT_ID);

        qihooPay.setNotifyUri(Constants.DEMO_APP_SERVER_NOTIFY_URI);

        qihooPay.setAppName(getString(R.string.demo_pay_app_name));
        qihooPay.setAppUserName(getString(R.string.demo_pay_app_user_name));
        qihooPay.setAppUserId(Constants.DEMO_PAY_APP_USER_ID);

        // 可选参数
        qihooPay.setAppExt1(getString(R.string.demo_pay_app_ext1));
        qihooPay.setAppExt2(getString(R.string.demo_pay_app_ext2));
        qihooPay.setAppOrderId("");

        return qihooPay;
    }

    private String getLoginResultText() {
        String result;
        if (mTokenInfo == null) {
            result = getString(R.string.nologin);
        } else {
            result = getString(R.string.formal_account);
            if (mTokenInfo != null && !TextUtils.isEmpty(mTokenInfo.getAccessToken())) {
                result += ("TokenInfo=" + mTokenInfo.toJsonString() + "\n\n");
            }

            if (mQihooUserInfo != null && mQihooUserInfo.isValid()) {
                result += ("UserInfo=" + mQihooUserInfo.toJsonString());
            }
        }

        return result;
    }

    private void clearLoginResult() {
        mTokenInfo = null;
        mQihooUserInfo = null;
        mLoginResultView.setText(getLoginResultText());
    }

    private void startSdkWelcomeActivity(boolean isLandScape) {
        Intent intent = new Intent(this, SdkWelcomeActivity.class);
        intent.putExtra(Constants.IS_LANDSCAPE, isLandScape);
        startActivity(intent);
        finish();
    }

}
