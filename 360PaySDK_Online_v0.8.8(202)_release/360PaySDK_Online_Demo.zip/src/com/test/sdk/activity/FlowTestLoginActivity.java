
package com.test.sdk.activity;

import com.qihoo.gamecenter.sdk.protocols.pay.ProtocolKeys;
import com.qihoopay.insdk.matrix.Matrix;
import com.test.sdk.R;
import com.test.sdk.appserver.QihooUserInfo;
import com.test.sdk.appserver.QihooUserInfoListener;
import com.test.sdk.appserver.QihooUserInfoTask;
import com.test.sdk.appserver.TokenInfo;
import com.test.sdk.appserver.TokenInfoListener;
import com.test.sdk.appserver.TokenInfoTask;
import com.test.sdk.common.QihooPayInfo;
import com.test.sdk.common.SdkUserBaseActivity;
import com.test.sdk.utils.ProgressUtil;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.Toast;

/**
 * 流程测试第一步，登录或注册登录。（注：流程测试第一步为，登录或注册登录；流程测试第二步为，定额支付或不定额支付。）
 * 此类调用360SDK完成登录过程，并把获取的AccessToken和UserId通过Intent传给流程测试第二步activity
 * ：FlowTestPayActivity
 */
public class FlowTestLoginActivity extends SdkUserBaseActivity implements OnClickListener,
        TokenInfoListener, QihooUserInfoListener {
    private static final String TAG = "FlowTestLoginActivity";

    // 进度等待框
    private ProgressDialog mProgress;

    // 登录返回的TokenInfo
    private TokenInfo mTokenInfo;

    private boolean mIsLandscape;

    private TokenInfoTask mTokenTask;
    private QihooUserInfoTask mUserInfoTask;

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_login:
                // 使用360SDK登录接口（横屏）
                doSdkLogin(mIsLandscape, true);
                break;
            default:
                break;
        }
    }

    /**
     * 360SDK登录，通过此方法返回授权码（授权码生存期只有60秒，必需立即请求应用服务器，以得到AccessToken）
     */
    @Override
    public void onGotAuthorizationCode(String authorizationCode) {
        Log.d(TAG, "onGotAuthorizationCode --> authorizationCode = " + authorizationCode);

        if (TextUtils.isEmpty(authorizationCode)) {
            Toast.makeText(this, R.string.get_code_fail, Toast.LENGTH_LONG).show();
        } else {
            mTokenTask = TokenInfoTask.newInstance();
            // 提示用户进度
            mProgress = ProgressUtil.show(this, R.string.get_token_title,
                    R.string.get_token_message, new OnCancelListener() {

                        @Override
                        public void onCancel(DialogInterface dialog) {
                            if (mTokenTask != null) {
                                mTokenTask.doCancel();
                            }
                        }
                    });

            // 请求应用服务器，用AuthorizationCode换取AccessToken
            mTokenTask.doRequest(this, authorizationCode, Matrix.getAppKey(this), this);
        }
    }

    /**
     * 应用服务器通过此方法返回AccessToken
     */
    @Override
    public void onGotTokenInfo(TokenInfo tokenInfo) {
        Log.d(TAG, "onGotTokenInfo ++++++++++++++");

        if (tokenInfo == null || TextUtils.isEmpty(tokenInfo.getAccessToken())) {
            ProgressUtil.dismiss(mProgress);
            Toast.makeText(this, R.string.get_token_fail, Toast.LENGTH_LONG).show();
        } else {
            // 保存TokenInfo
            mTokenInfo = tokenInfo;
            mUserInfoTask = QihooUserInfoTask.newInstance();

            // 提示用户进度
            ProgressUtil.setText(mProgress, getString(R.string.get_user_title),
                    getString(R.string.get_user_message), new OnCancelListener() {

                        @Override
                        public void onCancel(DialogInterface dialog) {
                            if (mUserInfoTask != null) {
                                mUserInfoTask.doCancel();
                            }
                        }
                    });

            // 请求应用服务器，用AccessToken换取UserInfo
            mUserInfoTask.doRequest(this, tokenInfo.getAccessToken(), Matrix.getAppKey(this),
                    this);
        }

    }

    /**
     * 应用服务器，通过此方法返回UserInfo
     */
    @Override
    public void onGotUserInfo(QihooUserInfo userInfo) {

        ProgressUtil.dismiss(mProgress);

        if (userInfo != null && userInfo.isValid()) {
            startFlowTestPayActivity(userInfo);
        } else {
            Toast.makeText(this, R.string.get_user_fail, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onGotError(int errCode) {
        // 不使用不用实现
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        if (intent != null) {
            mIsLandscape = intent.getBooleanExtra(ProtocolKeys.IS_SCREEN_ORIENTATION_LANDSCAPE,
                    true);

        }

        setRequestedOrientation(mIsLandscape ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setContentView(R.layout.flow_test_login_activity);
        initViews();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mTokenTask != null) {
            mTokenTask.doCancel();
        }
        
        if (mUserInfoTask != null) {
            mUserInfoTask.doCancel();
        }
    }

    private void initViews() {
        EditText appKey = (EditText) findViewById(R.id.value_app_key);
        appKey.setHint(Matrix.getAppKey(this));
        appKey.setOnClickListener(null);

        EditText appChannel = (EditText) findViewById(R.id.value_app_channel);
        appChannel.setHint(Matrix.getChannel(this));
        appChannel.setOnClickListener(null);

        // 登录按钮，点击后调用360SDK登录（竖屏显示界面）
        findViewById(R.id.btn_login).setOnClickListener(this);
    }

    /**
     * 启动流程第二步，自定义支付界面。 把UserId 和 AccessToken，通过Intent传递给FlowTestPayActivity
     */
    private void startFlowTestPayActivity(QihooUserInfo user) {
        Intent intent = new Intent(this, FlowTestPayActivity.class);
        intent.putExtra(FlowTestPayActivity.QIHOO_USER_ID, user.getId());
        intent.putExtra(FlowTestPayActivity.ACCESS_TOKEN, mTokenInfo.getAccessToken());
        intent.putExtra(ProtocolKeys.IS_SCREEN_ORIENTATION_LANDSCAPE, mIsLandscape);
        startActivity(intent);
    }

    @Override
    protected QihooPayInfo getQihooPayInfo(boolean isFixed) {
        return null;
    }

}
