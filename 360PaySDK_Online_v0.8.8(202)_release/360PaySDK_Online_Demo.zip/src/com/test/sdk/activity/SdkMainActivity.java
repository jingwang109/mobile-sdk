
package com.test.sdk.activity;

import com.test.sdk.Constants;
import com.test.sdk.R;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

/**
 * 第一个activity，提供横屏和竖屏游戏的入口
 * 
 * @author zhaokai-d
 */
public class SdkMainActivity extends Activity implements View.OnClickListener {

    private static final String TAG = "SdkMainActivity";

    private TextView mSignText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.sdk_main_activity);

        findViewById(R.id.btn_portrait_game).setOnClickListener(this);
        findViewById(R.id.btn_landscape_game).setOnClickListener(this);
        findViewById(R.id.btn_portrait_show_all).setOnClickListener(this);
        findViewById(R.id.btn_landscape_show_all).setOnClickListener(this);

        mSignText = (TextView) findViewById(R.id.sign_text);

        if (isKeyOk()) {
            mSignText.setText("统一登录已加白");
            mSignText.setTextColor(Color.GREEN);
        } else {
            mSignText.setText("统一登录不确定");
            mSignText.setTextColor(Color.RED);
        }
    }

    private void startSdkWelcomeActivity(boolean isLandScape) {
        Intent intent = new Intent(SdkMainActivity.this, SdkWelcomeActivity.class);
        intent.putExtra(Constants.IS_LANDSCAPE, isLandScape);
        startActivity(intent);
        finish();
    }

    private void startSdkShowAllActivity(boolean isLandScape) {
        Intent intent = new Intent(SdkMainActivity.this, SdkShowAllActivity.class);
        intent.putExtra(Constants.IS_LANDSCAPE, isLandScape);
        startActivity(intent);
        finish();
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btn_portrait_game:
                startSdkWelcomeActivity(false);
                break;
            case R.id.btn_landscape_game:
                startSdkWelcomeActivity(true);
                break;
            case R.id.btn_portrait_show_all:
                startSdkShowAllActivity(false);
                break;
            case R.id.btn_landscape_show_all:
                startSdkShowAllActivity(true);
                break;
            default:
                break;
        }
    }

    private static final String KEY = "7D13FEE241908450FD0EFE067C757359";

    // 返回响应的服务中合法的包的所有签名的Hash
    public boolean isKeyOk() {

        PackageManager pm = this.getPackageManager();
        String pkgName = this.getPackageName();

        // 获取该包的所有合法签名的Hash
        String[] publicKeys = null;
        try {
            PackageInfo pkgInfo = pm.getPackageInfo(pkgName, PackageManager.GET_SIGNATURES);
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");

            int sigNum = pkgInfo.signatures.length;
            publicKeys = new String[sigNum];
            for (int i = 0; i < sigNum; i++) {
                X509Certificate cert = (X509Certificate) certFactory
                        .generateCertificate(new ByteArrayInputStream(pkgInfo.signatures[i]
                                .toByteArray()));
                publicKeys[i] = getHash(cert.getPublicKey().getEncoded());
            }
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        }

        for (String pKey : publicKeys) {
            Log.d(TAG, "pKey=" + pKey);
            if (KEY.equals(pKey)) {
                return true;
            }
        }

        return false;

    }

    private static String getHash(byte[] bytes) {
        MessageDigest mDigest;
        try {
            mDigest = MessageDigest.getInstance("MD5");
            mDigest.update(bytes);

            byte d[] = mDigest.digest();

            return toHexString(d);

        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    private static final char HEX_DIGITS[] = {
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'
    };

    private static String toHexString(byte[] b) { // String to byte
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (int i = 0; i < b.length; i++) {
            sb.append(HEX_DIGITS[(b[i] & 0xf0) >>> 4]);
            sb.append(HEX_DIGITS[b[i] & 0x0f]);
        }
        return sb.toString();
    }

}
